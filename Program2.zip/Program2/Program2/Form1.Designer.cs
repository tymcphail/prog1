﻿namespace Program2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AgeLabel = new System.Windows.Forms.Label();
            this.DayLabel = new System.Windows.Forms.Label();
            this.BoatLabel = new System.Windows.Forms.Label();
            this.NumberLabel = new System.Windows.Forms.Label();
            this.YesButton = new System.Windows.Forms.RadioButton();
            this.NoButton = new System.Windows.Forms.RadioButton();
            this.DropDownBoat = new System.Windows.Forms.ComboBox();
            this.DropDownPeople = new System.Windows.Forms.ComboBox();
            this.CalculateButton = new System.Windows.Forms.Button();
            this.AgeIn = new System.Windows.Forms.TextBox();
            this.DayIn = new System.Windows.Forms.TextBox();
            this.PeopleCount = new System.Windows.Forms.TextBox();
            this.BPLabel = new System.Windows.Forms.Label();
            this.PPLabel = new System.Windows.Forms.Label();
            this.LJLabel = new System.Windows.Forms.Label();
            this.GTLabel = new System.Windows.Forms.Label();
            this.BPOut = new System.Windows.Forms.Label();
            this.HowManyLabel = new System.Windows.Forms.Label();
            this.LifeJacketGroupBox = new System.Windows.Forms.GroupBox();
            this.PPOut = new System.Windows.Forms.Label();
            this.PLJOut = new System.Windows.Forms.Label();
            this.GTOut = new System.Windows.Forms.Label();
            this.LifeJacketGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // AgeLabel
            // 
            this.AgeLabel.AutoSize = true;
            this.AgeLabel.Location = new System.Drawing.Point(458, 89);
            this.AgeLabel.Name = "AgeLabel";
            this.AgeLabel.Size = new System.Drawing.Size(35, 16);
            this.AgeLabel.TabIndex = 0;
            this.AgeLabel.Text = "Age:";
            // 
            // DayLabel
            // 
            this.DayLabel.AutoSize = true;
            this.DayLabel.Location = new System.Drawing.Point(451, 125);
            this.DayLabel.Name = "DayLabel";
            this.DayLabel.Size = new System.Drawing.Size(42, 16);
            this.DayLabel.TabIndex = 1;
            this.DayLabel.Text = "Days:";
            // 
            // BoatLabel
            // 
            this.BoatLabel.AutoSize = true;
            this.BoatLabel.Location = new System.Drawing.Point(452, 160);
            this.BoatLabel.Name = "BoatLabel";
            this.BoatLabel.Size = new System.Drawing.Size(41, 16);
            this.BoatLabel.TabIndex = 2;
            this.BoatLabel.Text = "Boat :";
            // 
            // NumberLabel
            // 
            this.NumberLabel.AutoSize = true;
            this.NumberLabel.Location = new System.Drawing.Point(374, 188);
            this.NumberLabel.Name = "NumberLabel";
            this.NumberLabel.Size = new System.Drawing.Size(119, 16);
            this.NumberLabel.TabIndex = 3;
            this.NumberLabel.Text = "Number of People:";
            // 
            // YesButton
            // 
            this.YesButton.AutoSize = true;
            this.YesButton.Location = new System.Drawing.Point(15, 27);
            this.YesButton.Name = "YesButton";
            this.YesButton.Size = new System.Drawing.Size(52, 20);
            this.YesButton.TabIndex = 4;
            this.YesButton.TabStop = true;
            this.YesButton.Text = "Yes";
            this.YesButton.UseVisualStyleBackColor = true;
            // 
            // NoButton
            // 
            this.NoButton.AutoSize = true;
            this.NoButton.Location = new System.Drawing.Point(15, 55);
            this.NoButton.Name = "NoButton";
            this.NoButton.Size = new System.Drawing.Size(46, 20);
            this.NoButton.TabIndex = 5;
            this.NoButton.TabStop = true;
            this.NoButton.Text = "No";
            this.NoButton.UseVisualStyleBackColor = true;
            // 
            // DropDownBoat
            // 
            this.DropDownBoat.FormattingEnabled = true;
            this.DropDownBoat.Items.AddRange(new object[] {
            "Speed Boat",
            "Pontoon Boat",
            "Canoe",
            "Houseboat",
            "Kayak",
            "none"});
            this.DropDownBoat.Location = new System.Drawing.Point(501, 157);
            this.DropDownBoat.Name = "DropDownBoat";
            this.DropDownBoat.Size = new System.Drawing.Size(121, 24);
            this.DropDownBoat.TabIndex = 6;
            // 
            // DropDownPeople
            // 
            this.DropDownPeople.FormattingEnabled = true;
            this.DropDownPeople.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "none"});
            this.DropDownPeople.Location = new System.Drawing.Point(501, 185);
            this.DropDownPeople.Name = "DropDownPeople";
            this.DropDownPeople.Size = new System.Drawing.Size(121, 24);
            this.DropDownPeople.TabIndex = 7;
            // 
            // CalculateButton
            // 
            this.CalculateButton.Location = new System.Drawing.Point(522, 302);
            this.CalculateButton.Name = "CalculateButton";
            this.CalculateButton.Size = new System.Drawing.Size(176, 22);
            this.CalculateButton.TabIndex = 8;
            this.CalculateButton.Text = "Calculate";
            this.CalculateButton.UseVisualStyleBackColor = true;
            this.CalculateButton.Click += new System.EventHandler(this.CalculateButton_Click);
            // 
            // AgeIn
            // 
            this.AgeIn.Location = new System.Drawing.Point(501, 86);
            this.AgeIn.Name = "AgeIn";
            this.AgeIn.Size = new System.Drawing.Size(100, 22);
            this.AgeIn.TabIndex = 9;
            // 
            // DayIn
            // 
            this.DayIn.Location = new System.Drawing.Point(501, 122);
            this.DayIn.Name = "DayIn";
            this.DayIn.Size = new System.Drawing.Size(100, 22);
            this.DayIn.TabIndex = 10;
            // 
            // PeopleCount
            // 
            this.PeopleCount.Location = new System.Drawing.Point(240, 24);
            this.PeopleCount.Name = "PeopleCount";
            this.PeopleCount.Size = new System.Drawing.Size(108, 22);
            this.PeopleCount.TabIndex = 11;
            // 
            // BPLabel
            // 
            this.BPLabel.AutoSize = true;
            this.BPLabel.Location = new System.Drawing.Point(332, 341);
            this.BPLabel.Name = "BPLabel";
            this.BPLabel.Size = new System.Drawing.Size(104, 16);
            this.BPLabel.TabIndex = 12;
            this.BPLabel.Text = "Price of the Boat";
            // 
            // PPLabel
            // 
            this.PPLabel.AutoSize = true;
            this.PPLabel.Location = new System.Drawing.Point(337, 367);
            this.PPLabel.Name = "PPLabel";
            this.PPLabel.Size = new System.Drawing.Size(99, 16);
            this.PPLabel.TabIndex = 13;
            this.PPLabel.Text = "Price of People";
            // 
            // LJLabel
            // 
            this.LJLabel.AutoSize = true;
            this.LJLabel.Location = new System.Drawing.Point(303, 397);
            this.LJLabel.Name = "LJLabel";
            this.LJLabel.Size = new System.Drawing.Size(126, 16);
            this.LJLabel.TabIndex = 14;
            this.LJLabel.Text = "Price of Life Jackets";
            // 
            // GTLabel
            // 
            this.GTLabel.AutoSize = true;
            this.GTLabel.Location = new System.Drawing.Point(345, 425);
            this.GTLabel.Name = "GTLabel";
            this.GTLabel.Size = new System.Drawing.Size(78, 16);
            this.GTLabel.TabIndex = 15;
            this.GTLabel.Text = "Grand Total";
            // 
            // BPOut
            // 
            this.BPOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BPOut.Location = new System.Drawing.Point(442, 341);
            this.BPOut.Name = "BPOut";
            this.BPOut.Size = new System.Drawing.Size(100, 23);
            this.BPOut.TabIndex = 16;
            // 
            // HowManyLabel
            // 
            this.HowManyLabel.AllowDrop = true;
            this.HowManyLabel.AutoSize = true;
            this.HowManyLabel.Location = new System.Drawing.Point(157, 27);
            this.HowManyLabel.Name = "HowManyLabel";
            this.HowManyLabel.Size = new System.Drawing.Size(77, 16);
            this.HowManyLabel.TabIndex = 20;
            this.HowManyLabel.Text = "How Many?";
            // 
            // LifeJacketGroupBox
            // 
            this.LifeJacketGroupBox.Controls.Add(this.YesButton);
            this.LifeJacketGroupBox.Controls.Add(this.HowManyLabel);
            this.LifeJacketGroupBox.Controls.Add(this.NoButton);
            this.LifeJacketGroupBox.Controls.Add(this.PeopleCount);
            this.LifeJacketGroupBox.Location = new System.Drawing.Point(362, 215);
            this.LifeJacketGroupBox.Name = "LifeJacketGroupBox";
            this.LifeJacketGroupBox.Size = new System.Drawing.Size(380, 81);
            this.LifeJacketGroupBox.TabIndex = 22;
            this.LifeJacketGroupBox.TabStop = false;
            this.LifeJacketGroupBox.Text = "Purchase Life Jackets?";
            // 
            // PPOut
            // 
            this.PPOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PPOut.Location = new System.Drawing.Point(442, 367);
            this.PPOut.Name = "PPOut";
            this.PPOut.Size = new System.Drawing.Size(100, 23);
            this.PPOut.TabIndex = 23;
            // 
            // PLJOut
            // 
            this.PLJOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PLJOut.Location = new System.Drawing.Point(442, 397);
            this.PLJOut.Name = "PLJOut";
            this.PLJOut.Size = new System.Drawing.Size(100, 23);
            this.PLJOut.TabIndex = 24;
            // 
            // GTOut
            // 
            this.GTOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.GTOut.Location = new System.Drawing.Point(442, 424);
            this.GTOut.Name = "GTOut";
            this.GTOut.Size = new System.Drawing.Size(100, 23);
            this.GTOut.TabIndex = 25;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 450);
            this.Controls.Add(this.GTOut);
            this.Controls.Add(this.PLJOut);
            this.Controls.Add(this.PPOut);
            this.Controls.Add(this.LifeJacketGroupBox);
            this.Controls.Add(this.BPOut);
            this.Controls.Add(this.GTLabel);
            this.Controls.Add(this.LJLabel);
            this.Controls.Add(this.PPLabel);
            this.Controls.Add(this.BPLabel);
            this.Controls.Add(this.DayIn);
            this.Controls.Add(this.AgeIn);
            this.Controls.Add(this.CalculateButton);
            this.Controls.Add(this.DropDownPeople);
            this.Controls.Add(this.DropDownBoat);
            this.Controls.Add(this.NumberLabel);
            this.Controls.Add(this.BoatLabel);
            this.Controls.Add(this.DayLabel);
            this.Controls.Add(this.AgeLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.LifeJacketGroupBox.ResumeLayout(false);
            this.LifeJacketGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label AgeLabel;
        private System.Windows.Forms.Label DayLabel;
        private System.Windows.Forms.Label BoatLabel;
        private System.Windows.Forms.Label NumberLabel;
        private System.Windows.Forms.RadioButton YesButton;
        private System.Windows.Forms.RadioButton NoButton;
        private System.Windows.Forms.ComboBox DropDownBoat;
        private System.Windows.Forms.ComboBox DropDownPeople;
        private System.Windows.Forms.Button CalculateButton;
        private System.Windows.Forms.TextBox AgeIn;
        private System.Windows.Forms.TextBox DayIn;
        private System.Windows.Forms.TextBox PeopleCount;
        private System.Windows.Forms.Label BPLabel;
        private System.Windows.Forms.Label PPLabel;
        private System.Windows.Forms.Label LJLabel;
        private System.Windows.Forms.Label GTLabel;
        private System.Windows.Forms.Label BPOut;
        private System.Windows.Forms.Label HowManyLabel;
        private System.Windows.Forms.GroupBox LifeJacketGroupBox;
        private System.Windows.Forms.Label PPOut;
        private System.Windows.Forms.Label PLJOut;
        private System.Windows.Forms.Label GTOut;
    }
}

