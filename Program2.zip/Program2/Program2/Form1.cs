﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }
        double BoatSum;
        double PeopleSum;
        double LifeJacketSum;
        double GrandTotal;
        int days;
        private void CalculateButton_Click(object sender, EventArgs e)
        {//Program 2,due march 10, S2335, this program calculates total cost to rent a boat
            const double Speed = 250.50;
            const double PricePerPerson = 25;
            const double Pontoon = 300.25;
            const double Canoe = 100;
            const double Houseboat = 1200;
            const double Kayak = 50;
            const double MinAge = 21;
            const double lifeJacketPrice = 15;


            int jackets;
            int age;
            
            


            int.TryParse(PeopleCount.Text, out jackets);

            if (int.TryParse(AgeIn.Text, out age) && age >= 21)
            {
                if (int.TryParse(DayIn.Text, out days) && days > 0)
                {
                    if (DropDownPeople.SelectedIndex >-1)
                    {
                        if (DropDownBoat.SelectedIndex > -1)
                        {
                            if (DropDownBoat.Text == "none")
                            { BoatSum = 0; }
                            else if (DropDownBoat.Text == "Speed Boat")
                            { BoatSum = Speed; }
                            else if (DropDownBoat.Text == "Pontoon")
                            { BoatSum = Pontoon; }

                            else if (DropDownBoat.Text == "Canoe")
                            { BoatSum = Canoe; }

                            else if (DropDownBoat.Text == "Houseboat")
                            { BoatSum = Houseboat; }

                            else if (DropDownBoat.Text == "Kayak")
                            { BoatSum = Kayak; }

                        }
                        else { MessageBox.Show("Please select a boat"); }

                        if (DropDownPeople.Text == "1")
                        {
                            PeopleSum = PricePerPerson;
                        }

                        else if (DropDownPeople.Text == "2")
                        {
                            PeopleSum = PricePerPerson * 2;
                        }

                        else if (DropDownPeople.Text == "3")
                        {
                            PeopleSum = PricePerPerson * 3;

                        }
                        else if (DropDownPeople.Text == "4")
                        {
                            PeopleSum = PricePerPerson * 4;
                        }

                    }
                    else
                    { MessageBox.Show("Please Enter a valid number of people"); }

                }
                else { MessageBox.Show("Please Enter a valid number of days"); }
            }
            else { MessageBox.Show($"Minimum age to rent is {MinAge}"); }
            //life jacket validation
            if (YesButton.Checked && jackets > 0)
            { LifeJacketSum = jackets * lifeJacketPrice; } //$15

            else { LifeJacketSum = 0; }

            //price of boat

            BPOut.Text = $"{BoatSum*days:c}";
            //price of people
            PPOut.Text = $"{PeopleSum:c}";
            //price of life jackets
            PLJOut.Text = $"{LifeJacketSum:c}";
            //grand total
            GrandTotal = (BoatSum*days) + PeopleSum + LifeJacketSum;
            GTOut.Text = $"{GrandTotal:c}";


        }
    }
}
